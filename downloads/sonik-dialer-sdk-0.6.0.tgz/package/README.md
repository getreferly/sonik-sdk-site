# Sonik Dialer SDK

Add Sonik's floating dialer to any JavaScript or TypeScript application. Your application supplies contacts; the hosted Sonik panel handles sign-in, audio, parallel calls and qualification.

## Install

Install the versioned SDK tarball provided by Sonik:

```sh
npm install ./sonik-dialer-sdk-0.6.0.tgz
```

The archive installs without registry authentication. Sonik maintains versioned archives in its private GitHub repository and can provide them directly to approved customers. Registry installation will be documented if an npm package becomes available.

## Connect

Ask Sonik to enable your application's origins and provide its HTTPS embed URL. For local development, Sonik can enable `http://localhost:*` to allow any localhost port; agent sign-in and calling permissions are still required. Production application origins are enabled individually. Use an existing Sonik agent account with calling access and an assigned caller ID.

```ts
import { SonikDialer, type Contact } from '@sonik/dialer-sdk';

const dialer = new SonikDialer({
  embedUrl: 'https://YOUR_SONIK_ORIGIN/embed/dialer',
});

dialer.on('qualification.saved', ({ contact, callId, outcome, notes }) => {
  // Save through your own authenticated CRM API using contact.externalId.
});

await dialer.mount();
const contacts: Contact[] = await loadContactsFromYourCrm();
await dialer.setContacts(contacts);
dialer.open();
```

Mounting displays a launcher without starting a call. The agent signs in through the panel's popup and starts each batch manually. Wait for both `authenticated` and `deviceReady` in `state.changed` before enabling host calling controls. Never load simulated numbers into live mode.

## Click to call and manual dialing

Call `await dialer.prefillDial(contact)` when someone clicks a phone number. It opens the panel and fills its Phone number input without starting a call or replacing the batch queue. Keep your CRM `externalId` on the contact so saved qualifications map back to the right record. The agent can sign in, edit the number, then press Call (or Enter) to place one direct call.

The panel also accepts a typed international number without loading contacts first. Include the country code; spaces, parentheses, dots and hyphens are accepted. Calling requires sign-in, a ready voice connection and an assigned caller ID. Prefilling is rejected during an active call or qualification. `dial(contact)` remains the API for starting a call immediately.

```ts
phoneButton.addEventListener('click', () => {
  void dialer.prefillDial(contact).catch(showError);
});
```

## Remembered sign-in

After signing in once, Sonik can restore your account after refreshing the host page or restarting the browser, for up to eight hours from the explicit sign-in. Automatic restoration does not extend the expiry. Keep the normal popup flow enabled for expiry, revocation or browsers that block embedded storage.

Calling tokens remain in iframe memory. The backend stores a separate opaque remember credential in a Secure, HttpOnly, SameSite=None, Partitioned cookie, bound to the approved host origin. Neither calling tokens nor remember credentials are exposed to the host application or stored in localStorage/sessionStorage. Each restored panel gets a separate SDK session and voice identity.

`mount()` still means the message bridge is ready; it does not mean authentication restoration has finished. Contacts can be supplied during restoration. Wait for `state.authenticated && state.deviceReady && !state.authRestoring && !state.authRestoreFailed && state.phase === 'idle'` before enabling host calling controls. The optional `authRestoring`, `authRestoreFailed` and `sessionRemembered` state fields describe progress and whether this browser retained the remember cookie. A failed restore offers Retry without discarding remembered access; cookie expiry/revocation returns to sign-in. No popup, microphone prompt or call is started automatically.

If a previous panel has an unfinished call under the same remembered login, `state.phase` becomes `recovering`. Sonik shows **End previous call** and blocks another call. This is explicit cancellation of the earlier operation, not audio reconnection or redialing. Failed cancellation keeps recovery controls available. `hangup()` and `destroy()` use those controls safely. Closing/reloading the page preserves remembered access; a successful explicit `destroy()`/Disconnect signs out and forgets it. Minimizing preserves calls and authentication.

Contact queues, qualification drafts and active audio are not restored by this feature. The host supplies contacts again after reload. Current browser privacy settings can prevent remembering sign-in; the panel explains this while allowing the current signed-in session to work.

Rollout requires the matching Sonik frontend and backend, including the new SDK auth endpoints and credentialed CORS for the configured Sonik frontend origin. Existing users sign in once after rollout to establish the cookie. No new Kinde callback URL, Redis service or database migration is required. Deployment and package publication are separate actions.

## API

### Optional call wrap-up

The after-call **Wrap up your call** form is enabled by default. Set `showWrapUp: false` when mounting to skip the outcome/notes step and return directly to **Ready to call** after call cleanup:

```ts
const dialer = new SonikDialer({ embedUrl, showWrapUp: false });
await dialer.mount();
```

This works in floating, side-panel and inline layouts. Call events and IDs are unchanged; the SDK does not submit an outcome or notes, and `qualification.saved` is not emitted for the skipped step. `qualifyCall()` and `skipQualification()` require an enabled, pending wrap-up. Failed cancellation still blocks the next call until cleanup succeeds. Your app can use the existing call events for its own follow-up workflow. Configure this option before mounting; reconnecting a panel resets its session.

### Methods and presentation

Methods: `prefillDial(contact)`, `mount()`, `open()`, `minimize()`, `setContacts()`, `startBatch()`, `dial()`, `hangup()`, `setMuted()`, `sendDigits()`, `qualifyCall()`, `skipQualification()`, `updateCallingSettings()`, `getState()`, `on()`, `off()` and asynchronous `destroy()`.

The default widget is dark, floating and draggable. Use `displayMode: 'side-panel'` for a compact fixed right panel (360 px wide by default, with 12 px viewport margins and internal scrolling). It opens on mount and can be minimized unless `alwaysOpen` is enabled. Reserve space in your application if you want the panel beside your content; it does not change your page layout or add a backdrop.

```ts
const dialer = new SonikDialer({
  embedUrl,
  displayMode: 'side-panel',
  alwaysOpen: true,
  width: 360,
});
await dialer.mount();
```

`alwaysOpen: true` also works with the default floating widget: opens immediately, hides the launcher/minimize controls and prevents `minimize()`, Escape or outside clicks from hiding it. Settings can still return to the dialer. Mounting never starts a call. Inline integration uses `{ displayMode: 'inline', container: '#dialer', embedUrl }` and is always visible. Minimize preserves calls and drafts when enabled. The settings cog saves the assigned caller ID and parallel line count to the agent's Sonik profile.

ESM entry: `@sonik/dialer-sdk`. Types/protocol entry: `@sonik/dialer-sdk/protocol`. Browser script: `dist/sonik-dialer.js`, exposing `window.Sonik.SonikDialer`; serve its adjacent `assets/` directory so logo assets load. The live panel is hosted by Sonik and is not included in this package. Browser-delivered JavaScript is inspectable even without source maps.

## Recovery and permissions

Commands never retry automatically. A timeout can leave an operation in progress: inspect state and events before another action. Failed qualification or settings saves retain drafts for an explicit retry. Failed destruction retains the widget with recovery controls; do not remove its frame yourself.

Allow the Sonik origin in your application's `frame-src` policy. Permit the sign-in popup and microphone. If your application is itself embedded, its containing iframe and Permissions-Policy must delegate microphone and autoplay to the Sonik origin. Only integrate in applications you trust; authenticated host scripts can request calls and receive contact details, outcomes and notes. Do not send those payloads to public logs or analytics.

TypeScript declarations include the complete method signatures and event payloads. Ask Sonik for a runnable example and the embed URL enabled for your application.

The embedded panel’s Calling settings include a microphone picker. Use **Enable / refresh microphones** to grant browser permission and load device names. The device choice applies immediately to the current panel and is retained when it is minimized; hardware IDs are not saved to the agent’s Sonik profile. Refresh after connecting or disconnecting a microphone.
